# DatabaseAssignment

This is an assignment for Database course of AUST. Here the basic works of a database like data insert, delete, column insert, delete 
operations were made through Java GUI. JFrame was used to make the GUI. The database was from a book.
